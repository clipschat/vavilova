<?php

return array(
	"Часто задаваемые вопросы" => "Faq",
	"Добавление вопроса" => "Add a question",
    "задать вопрос"  => "ask a question",
    "Разделы" => "Categories",
    "В данном разделе вопросы отсутствуют!" => "In this section, no questions!",
    "Вопрос" => "Question",
    "Ответ" => "Answer",
    "Ваш вопрос успешно добавлен" => "Your question has been successfully added"
);