<?php
$this->page_title = 'Редактирование раздела FAQ';

$this->tabs = array(
    "управление разделами" => $this->createUrl("manage")
);

echo $form;
?>