На сайте vavilova-13.ru был опубликован ответ на Ваш вопрос: <br>
<div><i><b><?=$model->question?></b></i></div>
<div><b><?=$model->answer?></b></div>
<div>
    Посмотреть ответ Вы можете по адресу:
    <a href="<?=$this->createAbsoluteUrl('/faq/faq/index')?>"><?=$this->createAbsoluteUrl('/faq/faq/index')?></a>.
</div>
<br />
______________________<br />
Данное письмо было сгенерировано службой автоматической рассылки. Просим Вас не отвечать на него.
Если у Вас возник вопрос по работе с сайтом, просим Вас обращаться по адресу:
vavilova@vavilova-13.ru
